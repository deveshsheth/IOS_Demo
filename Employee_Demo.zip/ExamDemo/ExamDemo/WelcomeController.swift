//
//  WelcomeController.swift
//  ExamDemo
//
//  Created by exam on 1/3/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class WelcomeController: UIViewController {

    @IBOutlet weak var sal: UITextField!
    var strName:String=""
    var deptname:String=""
    @IBOutlet weak var empName: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        empName.text=strName
        // Do any additional setup after loading the view.
    }

    @IBAction func submit(_ sender: Any) {
        performSegue(withIdentifier: "welcome", sender:nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var objdetail = segue.destination as? DetailController
        objdetail?.sal=sal.text!
        objdetail?.name=strName
        objdetail?.dept=deptname
    }

}
