//
//  DetailController.swift
//  ExamDemo
//
//  Created by exam on 1/3/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class DetailController: UIViewController {

    var dept:String=""
    var name:String=""
    var sal:String=""
    @IBOutlet weak var setname: UILabel!
     
    @IBOutlet weak var totalsal: UILabel!
    @IBOutlet weak var salary: UILabel!
    @IBOutlet weak var department: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        salary.text=sal
        setname.text=name
        department.text=dept
        
        var sal1=(Double)(sal)!
        var temp : Double = 0.8;
        var a:Double=0.35;
        var gp:Double=(Double(sal1+temp))
        var hra:Double=(Double(sal1+a))
        var totalsalary=sal1+gp+hra+400+100-1000
        totalsal.text=String(totalsalary)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
