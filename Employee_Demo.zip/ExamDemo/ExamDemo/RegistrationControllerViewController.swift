//
//  RegistrationControllerViewController.swift
//  ExamDemo
//
//  Created by exam on 1/3/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class RegistrationControllerViewController: UIViewController {

    @IBOutlet weak var btn_submit: UIButton!
    @IBOutlet weak var toggle: UISwitch!
    @IBOutlet weak var alert: UILabel!
    @IBOutlet weak var empdepartment: UITextField!
    @IBOutlet weak var empName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func toggle(_ sender: Any) {
        if(toggle.isOn){
            empName.isEnabled=true
            empdepartment.isEnabled=true
            btn_submit.isEnabled=true
        }else{
            empName.isEnabled=false
            empdepartment.isEnabled=false
            btn_submit.isEnabled=false
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func submit(_ sender: Any) {
        if(empName.text=="" && empdepartment.text==""){
            alert.text="invalid login"
        }
        else{
            performSegue(withIdentifier: "register", sender:nil)
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var objname = segue.destination as? WelcomeController
        objname?.strName=empName.text!
        objname?.deptname=empdepartment.text!
    }
    

}
