//
//  DataBaseController.swift
//  Allinone_ios
//
//  Created by exam on 3/16/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit
import CoreData // import codre data......

class DataBaseController: UIViewController {

    @IBOutlet weak var txt_rollno: UITextField!
    @IBOutlet weak var txt_name: UITextField!
    
    @IBOutlet weak var btn_first: UIButton!
    @IBOutlet weak var btn_prev: UIButton!
    @IBOutlet weak var btn_next: UIButton!
    @IBOutlet weak var btn_last: UIButton!
    
    var current:Int=0
    var isediting:Bool = false
    
    
    var db_studentArray:[NSManagedObject] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        current=0
        db_studentArray=getStudent() as [NSManagedObject]
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btn_save(_ sender: Any) {
        let appdel = UIApplication.shared.delegate as! AppDelegate
        let managedContext = appdel.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "DBStudents", in: managedContext)
        var stuobj = NSManagedObject()
        
        stuobj = NSManagedObject(entity: entity!,insertInto:managedContext)
        stuobj.setValue(txt_rollno.text ?? "", forKey:"db_name" )
        stuobj.setValue(txt_name.text ?? "", forKey:"db_rollno" )
        do{
            try managedContext.save()
            txt_rollno.text=""
            txt_name.text=""
            
            txt_rollno.becomeFirstResponder()
            
            let alert = UIAlertController(title: "Alert", message: "DAta saved in DB successfully", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title : "OK", style :  UIAlertActionStyle.default,handler : nil))
            self.present(alert,animated: true,completion: nil)
            
            db_studentArray=getStudent() as [NSManagedObject]
            
        }
        catch let err as NSError{
            //      print("err:\(err)")
        }

    }
    
    func getStudent() -> [NSManagedObject]{
        let appdel = UIApplication.shared.delegate as! AppDelegate
        var db_studentArray1:[NSManagedObject] = []
        let managedContext = appdel.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "DBStudents")
        do {
            db_studentArray1 = try managedContext.fetch(fetchRequest) as! [NSManagedObject]
        } catch let error as NSError {
            
        }
        return db_studentArray1
    }
    
    
    func setfieldvalue(){
        if current >= 0 && current < db_studentArray.count{
            
            txt_rollno.text=db_studentArray[current].value(forKey:"db_rollno")! as? String
            
            txt_name.text=db_studentArray[current].value(forKey: "db_name")! as? String
            
            
        }
    }
    
    func buttonenable_disable()
    {
        btn_first.isEnabled=true
        btn_last.isEnabled=true
        btn_next.isEnabled=true
        btn_prev.isEnabled=true
        
        if db_studentArray.count > 0 {
            if current == 0 {
                btn_first.isEnabled=false
                btn_prev.isEnabled=false
            }
            if current == db_studentArray.count-1 {
                btn_next.isEnabled=false
                btn_last.isEnabled=false
            }
        }
        else{
            btn_first.isEnabled=false
            btn_last.isEnabled=false
            btn_next.isEnabled=false
            btn_prev.isEnabled=false
        }
        
    }
    

    
    
    @IBAction func btn_print(_ sender: Any) {
        db_studentArray=getStudent()
        Swift.print("-------------------------------------")
        for i in 0...db_studentArray.count-1{
            Swift.print(db_studentArray[i].value(forKey : "db_rollno")!)
            Swift.print(db_studentArray[i].value(forKey : "db_name")!)
        }
    }
    
    @IBAction func btn_first(_ sender: Any) {
        isediting=true
        current=0
        setfieldvalue()
        buttonenable_disable()
    }
    
    @IBAction func btn_prev(_ sender: Any) {
        isediting=true
        current = current - 1
        setfieldvalue()
        buttonenable_disable()
    }
    
    @IBAction func btn_next(_ sender: Any) {
        isediting=true
        current = current + 1
        setfieldvalue()
        buttonenable_disable()
    }
    
    @IBAction func btn_last(_ sender: Any) {
        current = db_studentArray.count-1
        isediting=true
        setfieldvalue()
        buttonenable_disable()
    }
    
    @IBAction func btn_update(_ sender: Any) {
        let appdel = UIApplication.shared.delegate as! AppDelegate
        let managedContext = appdel.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "DBStudents", in: managedContext)
        var stuobj = NSManagedObject()
        if isediting{
            stuobj = db_studentArray[current]
        }
        else{
            stuobj = NSManagedObject(entity: entity!,insertInto:managedContext)
            
        }
        
        stuobj.setValue(txt_name.text ?? "", forKey:"db_name" )
        stuobj.setValue(txt_rollno.text ?? "", forKey:"db_rollno" )
        do{
            try managedContext.save()
            txt_name.text=""
            txt_rollno.text=""
            txt_rollno.becomeFirstResponder()
            let alert = UIAlertController(title: "Alert", message: "DAta updated successfully", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title : "OK", style :  UIAlertActionStyle.default,handler : nil))
            self.present(alert,animated: true,completion: nil)
            
            db_studentArray=getStudent() as [NSManagedObject]
            isediting=false
            
        }
        catch let err as NSError{
            //      print("err:\(err)")
        }
        

    }
    
    @IBAction func btn_delete(_ sender: Any) {
        
        let appdel = UIApplication.shared.delegate as! AppDelegate
        let managedContext = appdel.persistentContainer.viewContext
        if current >= 0 && current < db_studentArray.count{
            let stuobj = db_studentArray[current]
            managedContext.delete(stuobj)
            
            
            do{
                try managedContext.save()
                txt_name.text=""
                txt_rollno.text=""
                txt_rollno.becomeFirstResponder()
                let alert = UIAlertController(title: "Alert", message: "DAta deleted  successfully", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title : "OK", style :  UIAlertActionStyle.default,handler : nil))
                self.present(alert,animated: true,completion: nil)
                
            }
            catch let err as NSError{
                //      print("err:\(err)")
            }
            
            
        }
        
    }
    
}
