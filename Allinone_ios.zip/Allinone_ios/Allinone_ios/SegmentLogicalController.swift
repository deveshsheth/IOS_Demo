//
//  SegmentLogicalController.swift
//  Allinone_ios
//
//  Created by exam on 3/14/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class SegmentLogicalController: UIViewController {

    @IBOutlet weak var maintab: UISegmentedControl!
    
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    
    @IBOutlet weak var txt_principal: UITextField!
    
    @IBOutlet weak var txt_rate: UITextField!
    @IBOutlet weak var txt_years: UITextField!
    
    
    @IBOutlet weak var lbl_principal: UILabel!
    @IBOutlet weak var lbl_rate: UILabel!
    @IBOutlet weak var lbl_years: UILabel!
    @IBOutlet weak var lbl_result: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        maintab.selectedSegmentIndex=0
        
        view1.isHidden=false
        view2.isHidden=true
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btn_segment(_ sender: Any) {
        if(maintab.selectedSegmentIndex == 1){
            
            view1.isHidden=true
            view2.isHidden=false
            
        }else{
            
            view1.isHidden=false
            view2.isHidden=true
        }
    }
   

    
    @IBAction func btn_submit(_ sender: Any) {
    
        
        
    }
    

}
