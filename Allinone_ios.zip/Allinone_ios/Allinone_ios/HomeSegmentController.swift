//
//  HomeSegmentController.swift
//  Allinone_ios
//
//  Created by exam on 3/14/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class HomeSegmentController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btn_slider(_ sender: Any) {
        performSegue(withIdentifier: "segment_slider", sender: nil)
    }

    @IBAction func btn_logical(_ sender: Any) {
        performSegue(withIdentifier: "segment_logical", sender: nil)
        
    }
   
}
