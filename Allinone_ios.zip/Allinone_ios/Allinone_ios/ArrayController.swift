//
//  ArrayController.swift
//  Allinone_ios
//
//  Created by exam on 3/15/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class ArrayController: UIViewController {

    
    @IBOutlet weak var txt_rollno: UITextField!
    @IBOutlet weak var txt_name: UITextField!
    @IBOutlet weak var lbl_rollno: UILabel!
    @IBOutlet weak var lbl_name: UILabel!
    
    var appDelegate = UIApplication.shared.delegate as! AppDelegate
    var current:Int=0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btn_save(_ sender: Any) {
        
        let rollno = txt_rollno.text
        let stuname = txt_name.text
        
        //set values to NSObject student
        let stu = students()
        stu.rollno = Int(rollno!)
        stu.name = stuname
        
        appDelegate.arrstudents.append(stu)
        
        //empty the text fields
        txt_rollno.text=""
        txt_name.text=""
        
        txt_rollno.becomeFirstResponder()//bring focus to first textfield
        
        let alert = UIAlertController(title: "Alert", message: "Data Saved Successfully", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        
        self.present(alert,animated: true,completion: nil)

        
    }
 
    @IBAction func btn_print(_ sender: Any) {
        
        performSegue(withIdentifier: "arraylist_page", sender: nil)
        
        appDelegate.arrstudents.forEach(){
            
            print($0.rollno,$0.name)
            
        }
        
    }
   
    @IBAction func btn_first(_ sender: Any) {
        current=0
        lbl_rollno.text = String(appDelegate.arrstudents[current].rollno)
        lbl_name.text=appDelegate.arrstudents[current].name
    }
    
    @IBAction func btn_prev(_ sender: Any) {
        if current == 0{
            current = appDelegate.arrstudents.count
        }
        
        current = current-1
        print(current)
        lbl_rollno.text=String(appDelegate.arrstudents[current].rollno)
        lbl_name.text = appDelegate.arrstudents[current].name
    }
    
    @IBAction func btn_next(_ sender: Any) {
        
        if current == appDelegate.arrstudents.count-1
        {
            current=0
        }else{
            current=current+1
        }
        
        lbl_rollno.text=String(appDelegate.arrstudents[current].rollno)
        lbl_name.text = appDelegate.arrstudents[current].name

        
    }
    
    @IBAction func btn_last(_ sender: Any) {
        current = appDelegate.arrstudents.count-1
        lbl_rollno.text = String(appDelegate.arrstudents[current].rollno)
        lbl_name.text = appDelegate.arrstudents[current].name
    }
    
    
}
