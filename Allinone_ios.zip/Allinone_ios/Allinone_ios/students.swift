//
//  students.swift
//  Allinone_ios
//
//  Created by exam on 3/15/22.
//  Copyright © 2022 exam. All rights reserved.
//

import Foundation

class students{
    var rollno:Int!
    var name:String!
}
