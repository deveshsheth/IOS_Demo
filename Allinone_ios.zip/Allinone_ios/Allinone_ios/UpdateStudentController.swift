//
//  UpdateStudentController.swift
//  Allinone_ios
//
//  Created by exam on 3/15/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class UpdateStudentController: UIViewController {

    @IBOutlet weak var txt_rollno: UITextField!
    @IBOutlet weak var txt_name: UITextField!
    
    var appDelegate = UIApplication.shared.delegate as! AppDelegate

    
    override func viewDidLoad() {
        super.viewDidLoad()
        txt_rollno.text = String(appDelegate.arrstudents[appDelegate.selectedRow].rollno)
        
        txt_name.text = String(appDelegate.arrstudents[appDelegate.selectedRow].name)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btn_update(_ sender: Any) {
        appDelegate.arrstudents[appDelegate.selectedRow].rollno=Int(txt_rollno.text!)
        appDelegate.arrstudents[appDelegate.selectedRow].name=txt_name.text
        
        self.navigationController?.popViewController(animated: true)
        
    }

    

}
