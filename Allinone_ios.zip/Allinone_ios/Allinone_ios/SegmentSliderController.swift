//
//  SegmentSliderController.swift
//  Allinone_ios
//
//  Created by exam on 3/14/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class SegmentSliderController: UIViewController {

    @IBOutlet weak var maintab: UISegmentedControl!
    
    @IBOutlet weak var colorview: UIView!
    @IBOutlet weak var textview: UIView!
    @IBOutlet weak var red: UISlider!
    @IBOutlet weak var green: UISlider!
    @IBOutlet weak var blue: UISlider!
    @IBOutlet weak var txt_slider: UISlider!
    @IBOutlet weak var txt_size: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        maintab.selectedSegmentIndex=0
        
        colorview.isHidden=false
        textview.isHidden=true

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btn_maintab(_ sender: Any) {
        
        if(maintab.selectedSegmentIndex == 1){
            
            colorview.isHidden=true
            textview.isHidden=false
            
        }
        else{
            colorview.isHidden=false
            textview.isHidden=true        }

        
    }
    
    @IBAction func txt_slider(_ sender: Any) {
        self.txt_size.font = UIFont.systemFont(ofSize: CGFloat(txt_slider.value))
    }
    
    @IBAction func btn_colorslider(_ sender: Any) {
        var mycolor = UIColor(red: CGFloat(red.value/255), green: CGFloat(green.value/255), blue: CGFloat(blue.value/255), alpha: 1.0)
        
        self.view.backgroundColor = mycolor

    }

}
