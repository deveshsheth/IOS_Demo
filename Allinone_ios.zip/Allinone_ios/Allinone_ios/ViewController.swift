//
//  ViewController.swift
//  Allinone_ios
//
//  Created by exam on 3/14/22.
//  Copyright © 2022 exam. All rights reserved.
//


import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txt_name: UITextField!
    @IBOutlet weak var txt_num: UITextField!
    @IBOutlet weak var txt_cube: UITextField!
    @IBOutlet weak var txt_error: UILabel!
    
    var num:Int!
    var cube:Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btn_login(_ sender: Any) {
        
        var num = Int(txt_num.text!)!
        var cube = Int(txt_cube.text!)!
        
        var result = num*num*num
        
        if result == cube{
            performSegue(withIdentifier: "first", sender: nil)
        }else{
            txt_error.text="Invalid Credentials..!!"
        }
        
           }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var objname = segue.destination as? HomeController
        objname?.txt_user = txt_name.text!
        
    }

}

