//
//  HomeController.swift
//  Allinone_ios
//
//  Created by exam on 3/14/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class HomeController: UIViewController {

    @IBOutlet weak var txt_name: UILabel!
    var txt_user:String=""
    override func viewDidLoad() {
        super.viewDidLoad()

        txt_name.text=txt_user
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btn_segment(_ sender: Any) {
        performSegue(withIdentifier: "segment_page", sender: nil)
    }
    
    @IBAction func btn_array(_ sender: Any) {
        performSegue(withIdentifier: "array_page", sender: nil)
    }

    @IBAction func btn_database(_ sender: Any) {
        performSegue(withIdentifier: "database_page", sender: nil)
    }
}
