//
//  ViewController.swift
//  finalpractice
//
//  Created by exam on 14/03/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var num2: UITextField!
    @IBOutlet weak var num1: UITextField!
    var n1 : Int!
    var n2 : Int!
    var cube:Int=0;

    @IBOutlet weak var toggle: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func togglebtn(_ sender: UISwitch) {
        if(toggle.isOn==true)
        {
            submit.isEnabled = true
            name.isEnabled = true
            num1.isEnabled = true
            num2.isEnabled = true
        }
        else
        {
            submit.isEnabled = false
            name.isEnabled = false
            num1.isEnabled = false
            num2.isEnabled = false
        }
    }
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var error: UITextField!
    @IBOutlet weak var submit: UIButton!
    
    @IBAction func Submit(_ sender: UIButton) {
        n1 = Int(num1.text!)!
        n2 = Int(num2.text!)!
//        var cube:Int = (n1*n1*n1)
        cube=n1!*n1!*n1!
        if(n2==cube)
        {
            performSegue(withIdentifier:  "first", sender: nil)
        }
        else
        {
            error.text="plz enter valid value of num2"
        }
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var obj = segue.destination as? segment
        obj?.textuser = name.text!
    }
}

