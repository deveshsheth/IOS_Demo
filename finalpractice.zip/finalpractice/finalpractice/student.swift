//
//  student.swift
//  finalpractice
//
//  Created by exam on 15/03/22.
//  Copyright © 2022 exam. All rights reserved.
//

import Foundation
class student{
    var id:Int!
    var name:String!
    
}
