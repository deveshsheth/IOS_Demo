//
//  databaseview.swift
//  finalpractice
//
//  Created by exam on 16/03/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit
import CoreData

let appdel = UIApplication.shared.delegate as? AppDelegate
var emparray:[NSManagedObject] = []
var current:Int = 0
class databaseview: UIViewController {

    @IBOutlet weak var empnametxt: UITextField!
    @IBOutlet weak var empidtxt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func save(_ sender: UIButton) {
        let managecontext = appdel?.persistentContainer.viewContext
        let enity = NSEntityDescription.entity(forEntityName:  "Employee", in: managecontext!)
        var empobj = NSManagedObject()
        empobj = NSManagedObject(entity:  enity!, insertInto: managecontext)
        empobj.setValue(empidtxt.text ?? "", forKey: "id")
        empobj.setValue(empnametxt.text ?? "", forKey: "name")
        do {
                try managecontext?.save()
                empidtxt.text=""
                empnametxt.text=""
                var alert = UIAlertController(title:  "Alert", message: "data added successfully", preferredStyle : UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title:  "ok", style:UIAlertActionStyle.default, handler:nil))
            self.present(alert,animated : true,completion : nil)
            
            emparray=getEmployee() as [NSManagedObject]
            
            }
        catch let err as NSError{
        
        }
    }
   
    func getEmployee() -> [NSManagedObject]{
        //var emp1:[NSManagedObject]=[]
        let managecontext = appdel?.persistentContainer.viewContext
        var fetchrequest = NSFetchRequest<NSFetchRequestResult>(entityName:"Employee")
        do {
           emparray = try managecontext?.fetch(fetchrequest) as! [NSManagedObject]
        } catch let err as NSError{
             print(err)
        }
        return emparray
    }
    
    
    @IBAction func printbtn(_ sender: UIButton) {
        emparray = getEmployee()
        Swift.print("-----------------------------")
        for i in 0...emparray.count-1{
                Swift.print(emparray[i].value(forKey:"id")!)
                Swift.print(emparray[i].value(forKey:"name")!)
        }
        
    }
    
    @IBAction func first(_ sender: UIButton) {
        current=0
        setfieldvalue()
        
        
    }
    func setfieldvalue(){
        if current>=0 && current<emparray.count
        {
        empidtxt.text = emparray[current].value(forKey:  "id")! as? String
            
            empnametxt.text = emparray[current].value(forKey:  "name") as? String
        }
    }
    
    @IBAction func last(_ sender: UIButton) {
        current=emparray.count-1
        setfieldvalue()
    }
}

