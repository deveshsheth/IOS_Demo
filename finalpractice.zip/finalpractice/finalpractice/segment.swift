//
//  segment.swift
//  finalpractice
//
//  Created by exam on 14/03/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class segment: UIViewController {
    var textuser: String = ""
    
    @IBOutlet weak var blueslider: UISlider!
    @IBOutlet weak var greenslider: UISlider!
    @IBOutlet weak var redslider: UISlider!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var segmentout: UISegmentedControl!
    @IBOutlet weak var username: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        username.text = textuser
        
        segmentout.selectedSegmentIndex=0
        view1.isHidden=false
        view2.isHidden=true
        // Do any additional setup after loading the view.
    }

   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func segmentbtn(_ sender: UISegmentedControl) {
        if(segmentout.selectedSegmentIndex==0)
        {
            view1.isHidden=false
            view2.isHidden=true
            
            
        }
        else
        {
            view1.isHidden=true
            view2.isHidden=false
        }
        
    }
    
    @IBOutlet weak var fontslider: UISlider!
    @IBOutlet weak var label: UILabel!
    @IBAction func colorchange(_ sender: UISlider) {
        var mycolor = UIColor(red:CGFloat(redslider.value/255),green:CGFloat(greenslider.value/255),blue:CGFloat(blueslider.value/255),alpha:1.0)
        
        self.view.backgroundColor = mycolor
        
        
    }
    @IBAction func fontsize(_ sender: UISlider) {
        self.label.font=UIFont.systemFont(ofSize: CGFloat(fontslider.value))
        
    }

    @IBAction func arraybtn(_ sender: UIButton) {
        performSegue(withIdentifier:  "arraysegue", sender:  nil)
    }
}
