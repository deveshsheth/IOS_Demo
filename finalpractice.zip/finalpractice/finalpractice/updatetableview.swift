//
//  updatetableview.swift
//  finalpractice
//
//  Created by exam on 15/03/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class updatetableview: UIViewController {

    @IBOutlet weak var idTxt: UITextField!
    @IBOutlet weak var nameTxt: UITextField!
    var appDelegate=UIApplication.shared.delegate as! AppDelegate
    override func viewDidLoad() {
        super.viewDidLoad()
        idTxt.text=String(appDelegate.arrstudent[appDelegate.selectedrow].id)
        nameTxt.text=appDelegate.arrstudent[appDelegate.selectedrow].name
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func updateBtnclick(_ sender: UIButton) {
        appDelegate.arrstudent[appDelegate.selectedrow].id=Int(idTxt.text!)
        appDelegate.arrstudent[appDelegate.selectedrow].name=nameTxt.text
        self.navigationController?.popViewController(animated: true)
    }
  

}
