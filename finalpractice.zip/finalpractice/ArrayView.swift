//
//  ArrayView.swift
//  finalpractice
//
//  Created by exam on 15/03/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class ArrayView: UIViewController {

    @IBOutlet weak var name_txt: UITextField!
    @IBOutlet weak var id_txt: UITextField!
    var appdel = UIApplication.shared.delegate as? AppDelegate
    var current : Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
 
    @IBAction func savebtn(_ sender: UIButton) {
        var stu = student()
        stu.id = Int(id_txt.text!)!
        stu.name = name_txt.text
        
        appdel?.arrstudent.append(stu)
        
        id_txt.text = ""
        name_txt.text = ""
        
        id_txt.becomeFirstResponder()
        
        
    }
    
    @IBAction func printbtn(_ sender: UIButton) {
        appdel?.arrstudent.forEach(){
            print($0.id,$0.name)
        }
    }

    @IBAction func deletebtn(_ sender: UIButton) {
        appdel?.arrstudent.remove(at:  current)
        current=current-1
     }
    
    
    @IBAction func firstbtn(_ sender: UIButton) {
        current=0
        id_txt.text = String(describing: appdel?.arrstudent[current].id!)
        name_txt.text = appdel?.arrstudent[current].name
    }
    
    @IBAction func nextbtn(_ sender: UIButton) {
        if current == (appdel?.arrstudent.count)!-1
        {
            current = 0
        }
        else
        {
            current = current + 1
            
        }
   
        id_txt.text = String(describing: appdel?.arrstudent[current].id!)
        name_txt.text = appdel?.arrstudent[current].name

    }

    @IBAction func prevbtn(_ sender: UIButton) {
        if  current == 0 {
            current = (appdel?.arrstudent.count)!-1

        }
        else{
            current = current - 1
        }
        id_txt.text = String(describing: appdel?.arrstudent[current].id!)
        name_txt.text = appdel?.arrstudent[current].name


    }

    @IBAction func database(_ sender: UIButton) {
        performSegue(withIdentifier:  "database", sender: nil)
    }
    @IBAction func lastbtn(_ sender: UIButton) {
        current = (appdel?.arrstudent.count)!-1
        id_txt.text = String(describing: appdel?.arrstudent[current].id!)
        name_txt.text = appdel?.arrstudent[current].name

    }
    @IBAction func tableviewbtn(_ sender: UIButton) {
        performSegue(withIdentifier:  "tablesegue", sender: nil)
    }
}
