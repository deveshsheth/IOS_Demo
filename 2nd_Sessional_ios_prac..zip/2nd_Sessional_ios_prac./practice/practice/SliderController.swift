//
//  SliderController.swift
//  practice
//
//  Created by exam on 16/02/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class SliderController: UIViewController {

    @IBOutlet weak var red: UISlider!
    @IBOutlet weak var blue: UISlider!
    @IBOutlet weak var green: UISlider!
    @IBOutlet weak var textsize: UILabel!
    @IBOutlet weak var textslider: UISlider!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btn_changecolor(_ sender: Any) {
        
        var mycolor = UIColor(red: CGFloat(red.value/255), green: CGFloat(green.value/255), blue: CGFloat(blue.value/255), alpha: 1.0)
        
        self.view.backgroundColor = mycolor
        
    }

    @IBAction func btn_textsize(_ sender: Any) {
        self.textsize.font = UIFont.systemFont(ofSize: CGFloat(textslider.value))
    }
  

}
