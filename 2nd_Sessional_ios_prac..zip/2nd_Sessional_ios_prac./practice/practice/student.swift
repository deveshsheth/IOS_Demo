//
//  student.swift
//  practice
//
//  Created by exam on 16/02/22.
//  Copyright © 2022 exam. All rights reserved.
//

import Foundation

class student{
    
    var num:Int!
    var name:String!
}
