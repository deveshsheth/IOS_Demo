//
//  StudentController.swift
//  practice
//
//  Created by exam on 16/02/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class StudentController: UIViewController {

    @IBOutlet weak var txtnum: UITextField!
    @IBOutlet weak var txtname: UITextField!
    
    @IBOutlet weak var lblnum: UILabel!
    @IBOutlet weak var lblname: UILabel!
    
    var appDelegate = UIApplication.shared.delegate as! AppDelegate
    var current:Int=0
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btn_nextpage(_ sender: Any) {
        performSegue(withIdentifier: "studentlist", sender: nil)
    }

    @IBAction func btn_save(_ sender: Any) {
        
        let number = txtnum.text
        let stuname = txtname.text
        
        //set values to NSObject student
        let stu = student()
        stu.num = Int(number!)
        stu.name = stuname
        
        appDelegate.arrstudent.append(stu)
        
        //empty the text fields
        txtnum.text=""
        txtname.text=""
        
        txtnum.becomeFirstResponder()//bring focus to first textfield
        
        let alert = UIAlertController(title: "Alert", message: "Data Saved Successfully", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        
        self.present(alert,animated: true,completion: nil)
    }
   
    @IBAction func btn_print(_ sender: Any) {
        appDelegate.arrstudent.forEach(){

            print($0.num,$0.name)
        
        }
    }
    
    @IBAction func btn_firstplace(_ sender: Any) {
        current=0
        lblnum.text = String(appDelegate.arrstudent[current].num)
        lblname.text=appDelegate.arrstudent[current].name
    }
    
    @IBAction func btn_prevplace(_ sender: Any) {
        if current == 0{
            current = appDelegate.arrstudent.count
        }
        
        current = current-1
        print(current)
        lblnum.text=String(appDelegate.arrstudent[current].num)
        lblname.text = appDelegate.arrstudent[current].name
    }
    
    @IBAction func btn_nextplace(_ sender: Any) {
    
        if current == appDelegate.arrstudent.count-1
        {
            current=0
        }else{
            current=current+1
        }
        
        lblnum.text=String(appDelegate.arrstudent[current].num)
        lblname.text = appDelegate.arrstudent[current].name
    }
    
    
    @IBAction func btn_lastplace(_ sender: Any) {
        current = appDelegate.arrstudent.count-1
        lblnum.text = String(appDelegate.arrstudent[current].num)
        lblname.text = appDelegate.arrstudent[current].name
    }
    
    
    @IBAction func btn_updateplace(_ sender: Any) {
        if txtnum.text=="" && txtname.text=="" {
            txtnum.text = String(appDelegate.arrstudent[current].num)
            txtname.text = appDelegate.arrstudent[current].name
        }else{
            appDelegate.arrstudent[current].num = Int(txtnum.text!)!
            appDelegate.arrstudent[current].name = txtname.text
        }
    }
    
    @IBAction func btn_deleteplace(_ sender: Any) {

        appDelegate.arrstudent.remove(at: current)
        current=current-1
        
    }
    
    
}
