//
//  TabsController.swift
//  practice
//
//  Created by exam on 16/02/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class TabsController: UIViewController {

    @IBOutlet weak var maintab: UISegmentedControl!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view1: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        maintab.selectedSegmentIndex=0
        
        view1.isHidden=false
        view2.isHidden=true
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btn_segment(_ sender: Any) {
        if(maintab.selectedSegmentIndex == 0){
            
            view1.isHidden=true
            view2.isHidden=false
        
        }
        else{
            view1.isHidden=false
            view2.isHidden=true        }
    }
    

}
