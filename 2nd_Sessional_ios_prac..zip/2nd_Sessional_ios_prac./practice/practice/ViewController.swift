//
//  ViewController.swift
//  practice
//
//  Created by exam on 16/02/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var number: UITextField!
    
    @IBOutlet weak var error: UILabel!
    
    var num1:Int = 0;
    var num2:Int = 0;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func loginBtn(_ sender: Any) {
        
        var num1 = Int(name.text!)!
        var num2 = Int(number.text!)!
        
        var cube = num1*num1*num1
        
        if cube == num2 {
            
            performSegue(withIdentifier: "first", sender: nil)
        
        }else{
            error.text="Invalid Credentials..!!!!"
        }
        
    }

}

