//
//  SecondController.swift
//  practice
//
//  Created by exam on 16/02/22.
//  Copyright © 2022 exam. All rights reserved.
//

import UIKit

class SecondController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btn_slider(_ sender: Any) {
        performSegue(withIdentifier: "slider", sender: nil)
    }
    @IBAction func btn_segement(_ sender: Any) {
        performSegue(withIdentifier: "segment", sender: nil)
    }
    @IBAction func btn_student(_ sender: Any) {
        performSegue(withIdentifier: "stud", sender: nil)
    }
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
